"""
CLI related constants

These are in their own file so they can be imported by differen CLI modules.
"""

NAME = "pro"
USAGE_TMPL = "{name} {command} [flags]"
